<?php
$input=getenv('POPCLIP_TEXT');
echo base64_encode($input);
?>