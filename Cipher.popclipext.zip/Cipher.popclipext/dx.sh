#!/bin/bash
result=$(python dx.py "$POPCLIP_TEXT")
echo "$result"
