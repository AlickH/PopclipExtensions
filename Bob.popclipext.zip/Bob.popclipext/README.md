# Bob PopClip Extension

## 功能

本插件主要用于快捷调用 [Bob](https://github.com/ripperhe/Bob) App，点击之后即可立即翻译，如需使用，请确认是从以下链接下载的插件

## 网页链接

* 插件下载地址 <https://github.com/ripperhe/Bob-PopClip>
* Bob 下载地址 <https://github.com/ripperhe/Bob>