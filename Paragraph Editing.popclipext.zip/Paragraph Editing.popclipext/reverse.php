<?php
mb_internal_encoding("UTF-8"); 

// 直接用 \n 作为换行符分割，兼容性更好
$lines = explode("\n", getenv('POPCLIP_TEXT'));

// 反转数组
$result = array_reverse($lines);

// 正确的 implode 用法
echo implode("\n", $result);
?>