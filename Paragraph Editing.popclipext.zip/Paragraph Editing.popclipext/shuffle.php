<?php
$lines = explode("\n", getenv('POPCLIP_TEXT'));
shuffle($lines);  // 直接打乱 $lines
echo implode("\n", $lines); // 这里要使用 $lines，而不是 $result
?>