#!/bin/bash

dialog() {
	./dialog/Contents/MacOS/cocoaDialog bubble \
		--title "$POPCLIP_TEXT" \
		--icon-file ud.png \
		--text "$@"
}

result=$(./urban "$POPCLIP_URLENCODED_TEXT" all)
dialog "$result"
