#!/bin/bash

dialog() {
	./dialog/Contents/MacOS/cocoaDialog bubble \
		--title "$POPCLIP_TEXT" \
		--icon-file yd.png \
		--text "$@"
}

result=$(curl -sSL "http://dict.youdao.com/m/search?q=$POPCLIP_URLENCODED_TEXT" | sed -ne '/网络释义/,/更多释义/p' | grep '<li>' | sed -e 's/<[^>]*>//g')
dialog "$result"
