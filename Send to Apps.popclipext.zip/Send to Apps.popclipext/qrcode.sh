#!/bin/bash

exec ./qrcode -p -t "$POPCLIP_TEXT"
