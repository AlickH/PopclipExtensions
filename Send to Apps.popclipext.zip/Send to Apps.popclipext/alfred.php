<?php
$text = getenv('POPCLIP_TEXT');

// 生成 AppleScript 语句
$applescript = 'tell application id "com.runningwithcrayons.Alfred" to search "' . str_replace('"', '\"', $text) . '"';

// 执行 osascript，确保传入完整的 AppleScript 语句
shell_exec("osascript -e " . escapeshellarg($applescript));
?>