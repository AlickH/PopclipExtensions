input=ENV['POPCLIP_TEXT']
print input.upcase
