<?php
mb_internal_encoding("UTF-8");
$input=getenv('POPCLIP_TEXT');
echo '"'.$input.'"';
?>
