result=`echo $POPCLIP_TEXT | perl titlecase.pl`
/bin/echo -n $result